import { NextRequest, NextResponse } from 'next/server'
import { sendContactEmails } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, phone, subject, message } = body

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { success: false, error: 'Name, email, subject, and message are required.' },
        { status: 400 },
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address.' },
        { status: 400 },
      )
    }

    // Send both emails: admin notification + submitter acknowledgement
    await sendContactEmails({ name, email, phone, subject, message })

    return NextResponse.json({
      success: true,
      message: 'Thank you for reaching out! We will get back to you shortly.',
    })
  } catch (error) {
    console.error('Contact form error:', error)

    const message =
      error instanceof Error ? error.message : 'An unexpected error occurred. Please try again.'

    return NextResponse.json(
      { success: false, error: message },
      { status: 500 },
    )
  }
}
